package robot_worlds_13.server.robot;

/**
 * Represents the cardinal directions: NORTH, SOUTH, EAST, and WEST.
 */
public enum Direction {
    NORTH, SOUTH, EAST, WEST
}
